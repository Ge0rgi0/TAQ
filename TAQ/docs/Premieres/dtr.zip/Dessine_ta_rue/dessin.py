import turtle
from typing import List, Tuple, Type, Optional

class Dessin:
    """
    Représente un dessin composé de formes géométriques (arc, triangle, rectangle).
    
    Attributs :
        formes (List[Forme]) : Liste des formes ajoutées au dessin.
        color_bg (str) : Couleur de fond du dessin (par défaut : "white").
    """
    
    def __init__(self, color_bg: str = "white") -> None:
        """
        Initialise un dessin vide avec une couleur de fond.

        Paramètres :
            color_bg (str) : Couleur de fond du dessin. Par défaut "white".
        """
        self.formes: List[Forme] = []
        self.color_bg = color_bg

    def __eq__(self, value: object) -> bool:
        """
        Vérifie si deux dessins sont égaux, c'est-à-dire s'ils contiennent
        exactement les mêmes formes dans le même ordre.

        Paramètres :
            value (object) : L'objet à comparer.

        Retourne :
            bool : True si les deux dessins sont égaux, False sinon.
            
        >>> d1 = Dessin()
        >>> d2 = Dessin()
        >>> d1 == d2
        True
        >>> d1.dessine_arc(50, 90, (750, 250))
        >>> d1 == d2
        False
        """
        return isinstance(value, Dessin) and self.formes == value.formes

    def __len__(self) -> int:
        """
        Renvoie le nombre de formes contenues dans le dessin.

        Retourne :
            int : Nombre de formes.
            
        >>> d = Dessin()
        >>> len(d)
        0
        >>> d.dessine_rectangle((750, 250), 100, 50)
        >>> len(d)
        1
        """
        return len(self.formes)

    def formes_par_type(self, type_forme: Type["Forme"]) -> List["Forme"]:
        """
        Renvoie la liste des formes du dessin qui sont d'un type donné.

        Paramètres :
            type_forme (Type[Forme]) : Le type de forme recherché (ex : Triangle, Arc...).

        Retourne :
            List[Forme] : Liste des formes correspondant au type spécifié.
        
        >>> d = Dessin()
        >>> d.dessine_triangle([(750, 250), (760, 250), (755, 260)])
        >>> d.dessine_rectangle((750, 250), 100, 50)
        >>> len(d.formes_par_type(Triangle))
        1
        >>> len(d.formes_par_type(Rectangle))
        1
        """
        return [forme for forme in self.formes if isinstance(forme, type_forme)]

    def ajoute_arc(self, rayon: int, angle: int, coordonnees: Tuple[int, int],
                    couleur: str = "black", contour: Optional[str] = None) -> None:
        """
        Ajoute un arc au dessin.

        Paramètres :
            rayon (int) : Rayon de l'arc.
            angle (int) : Angle en degrés.
            coordonnees (Tuple[int, int]) : Position du centre de l'arc avant ajustement.
            couleur (str) : Couleur de remplissage. Par défaut "black".
            contour (Optional[str]) : Couleur du contour. Par défaut identique à la couleur.
        
        >>> d = Dessin()
        >>> d.dessine_arc(30, 180, (750, 250))
        >>> isinstance(d.formes[0], Arc)
        True
        """
        self.formes.append(Arc(rayon, angle, coordonnees, couleur, contour))

    def ajoute_triangle(self, points: List[Tuple[int, int]], couleur: str = "black",
                         contour: Optional[str] = None) -> None:
        """
        Ajoute un triangle au dessin.

        Paramètres :
            points (List[Tuple[int, int]]) : Liste de 3 sommets (x, y) du triangle.
            couleur (str) : Couleur de remplissage. Par défaut "black".
            contour (Optional[str]) : Couleur du contour. Par défaut identique à la couleur.
            
        >>> d = Dessin()
        >>> d.dessine_triangle([(750, 250), (760, 250), (755, 260)])
        >>> isinstance(d.formes[0], Triangle)
        True
        """
        self.formes.append(Triangle(points, couleur, contour))

    def ajoute_rectangle(self, coin: Tuple[int, int], largeur: int, hauteur: int,
                          couleur: str = "black", contour: Optional[str] = None) -> None:
        """
        Ajoute un rectangle au dessin.

        Paramètres :
            coin (Tuple[int, int]) : Coordonnées du coin inférieur gauche avant ajustement.
            largeur (int) : Largeur du rectangle.
            hauteur (int) : Hauteur du rectangle.
            couleur (str) : Couleur de remplissage. Par défaut "black".
            contour (Optional[str]) : Couleur du contour. Par défaut identique à la couleur.
            
        >>> d = Dessin()
        >>> d.dessine_rectangle((750, 250), 100, 50)
        >>> isinstance(d.formes[0], Rectangle)
        True
        """
        self.formes.append(Rectangle(coin, largeur, hauteur, couleur, contour))

    def affiche(self) -> None:
        """
        Affiche le dessin dans une fenêtre Turtle avec la couleur de fond spécifiée.
        Toutes les formes ajoutées sont dessinées dans l'ordre d'insertion.
        """
        turtle.speed(0)
        turtle.bgcolor(self.color_bg)
        
        for forme in self.formes:
            forme.dessiner()
        
        turtle.hideturtle()
        turtle.done()

class Forme:
    """
    Classe de base représentant une forme géométrique.

    Attributs :
        couleur (str) : Couleur de remplissage de la forme.
        contour (str) : Couleur du contour de la forme.

    >>> f1 = Forme("red", "blue")
    >>> f1.couleur
    'red'
    >>> f1.contour
    'blue'
    >>> f2 = Forme("red", "blue")
    >>> f1 == f2
    True
    >>> repr(f1)
    "Forme('red', 'blue')"
    """

    def __init__(self, couleur: str = "black", contour: Optional[str] = None) -> None:
        """
        Initialise une forme avec une couleur de remplissage et un contour.

        Paramètres :
            couleur (str) : Couleur de remplissage. Par défaut "black".
            contour (Optional[str]) : Couleur du contour. Par défaut la même que la couleur de remplissage.
        """
        self.couleur = couleur
        if contour is None:
            self.contour = couleur
        else:
            self.contour = contour

    def __repr__(self) -> str:
        """
        Représentation textuelle de la forme.

        Retourne :
            str : Représentation de l'objet sous forme de chaîne.
        """
        return f"{self.__class__.__name__}({', '.join(repr(v) for v in self.__dict__.values())})"

    def __eq__(self, other: object) -> bool:
        """
        Compare deux objets pour l'égalité.

        Paramètres :
            other (object) : L'autre objet à comparer.

        Retourne :
            bool : True si les deux objets sont du même type et ont les mêmes attributs.
        """
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __hash__(self) -> int:
        """
        Calcule un hash de l'objet.

        Retourne :
            int : Valeur de hash.
        """
        return hash(tuple(self.__dict__.values()))


class Arc(Forme):
    """
    Classe représentant un arc de cercle.
    
    Attributs :
        rayon (int) : Rayon de l'arc.
        angle (int) : Angle en degrés.
        coordonnees (Tuple[int, int]) : Coordonnées du centre de l'arc, ajustées.

    >>> a = Arc(50, 180, (750, 250), "red")
    >>> a.rayon
    50
    >>> a.angle
    180
    >>> a.coordonnees
    (0, 0)
    >>> isinstance(a, Forme)
    True
    """

    def __init__(self, rayon: int, angle: int, coordonnees: Tuple[int, int], couleur: str = "black", contour: Optional[str] = None) -> None:
        """
        Initialise un arc.

        Paramètres :
            rayon (int) : Rayon de l'arc.
            angle (int) : Angle de l'arc en degrés.
            coordonnees (Tuple[int, int]) : Coordonnées du centre de l'arc avant ajustement.
            couleur (str) : Couleur de remplissage. Par défaut "black".
            contour (Optional[str]) : Couleur du contour. Par défaut la même que la couleur.
        """
        super().__init__(couleur, contour)
        self.rayon = rayon
        self.angle = angle
        self.coordonnees = coordonnees[0] - 750, coordonnees[1] - 250

    def dessiner(self) -> None:
        """
        Dessine l'arc à l'écran avec turtle.
        """
        turtle.screensize(100,100)
        turtle.penup()
        turtle.goto(self.coordonnees[0], self.coordonnees[1] - self.rayon)
        turtle.pendown()
        turtle.pencolor(self.contour)
        turtle.fillcolor(self.couleur)
        turtle.begin_fill()
        turtle.circle(self.rayon, self.angle)
        turtle.end_fill()


class Triangle(Forme):
    """
    Classe représentant un triangle.
    
    Attributs :
        points (List[Tuple[int, int]]) : Liste des trois sommets du triangle, ajustés.

    >>> t = Triangle([(750, 250), (760, 250), (755, 260)], "green")
    >>> t.points
    [(0, 0), (10, 0), (5, 10)]
    >>> isinstance(t, Forme)
    True
    """

    def __init__(self, points: List[Tuple[int, int]], couleur: str = "black", contour: Optional[str] = None) -> None:
        """
        Initialise un triangle.

        Paramètres :
            points (List[Tuple[int, int]]) : Liste de 3 tuples représentant les sommets du triangle avant ajustement.
            couleur (str) : Couleur de remplissage. Par défaut "black".
            contour (Optional[str]) : Couleur du contour. Par défaut la même que la couleur.
        """
        super().__init__(couleur, contour)
        self.points = [(p[0] - 750, p[1] - 250) for p in points]

    def dessiner(self) -> None:
        """
        Dessine le triangle à l'écran avec turtle.
        """
        turtle.penup()
        turtle.goto(self.points[0])
        turtle.pendown()
        turtle.pencolor(self.contour)
        turtle.fillcolor(self.couleur)
        turtle.begin_fill()
        for point in self.points[1:] + [self.points[0]]:
            turtle.goto(point)
        turtle.end_fill()


class Rectangle(Forme):
    """
    Classe représentant un rectangle.

    Attributs :
        coin (Tuple[int, int]) : Coordonnées du coin inférieur gauche après ajustement.
        largeur (int) : Largeur du rectangle.
        hauteur (int) : Hauteur du rectangle.

    >>> r = Rectangle((750, 250), 100, 50, "blue")
    >>> r.coin
    (0, 0)
    >>> r.largeur
    100
    >>> r.hauteur
    50
    >>> isinstance(r, Forme)
    True
    """

    def __init__(self, coin: Tuple[int, int], largeur: int, hauteur: int, couleur: str = "black", contour: Optional[str] = None) -> None:
        """
        Initialise un rectangle.

        Paramètres :
            coin (Tuple[int, int]) : Coordonnées du coin inférieur gauche avant ajustement.
            largeur (int) : Largeur du rectangle.
            hauteur (int) : Hauteur du rectangle.
            couleur (str) : Couleur de remplissage. Par défaut "black".
            contour (Optional[str]) : Couleur du contour. Par défaut la même que la couleur.
        """
        super().__init__(couleur, contour)
        self.coin = coin[0] - 750, coin[1] - 250
        self.largeur = largeur
        self.hauteur = hauteur

    def dessiner(self) -> None:
        """
        Dessine le rectangle à l'écran avec turtle.
        """
        x, y = self.coin
        turtle.penup()
        turtle.goto(x, y)
        turtle.pendown()
        turtle.pencolor(self.contour)
        turtle.fillcolor(self.couleur)
        turtle.begin_fill()
        for dx, dy in [(self.largeur, 0), (0, self.hauteur), (-self.largeur, 0), (0, -self.hauteur)]:
            turtle.goto(x + dx, y + dy)
            x, y = x + dx, y + dy
        turtle.end_fill()
