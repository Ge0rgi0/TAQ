# Importation du module
import scene
# Création de l'objet Rue
ma_rue = scene.Scene()
'''
Dessine un rectangle :
- de coordonnées (0,0)
- de hauteur 100
- de largeur 100
- de couleur noir
'''
ma_rue.ajoute_rectangle((0,0),100,100,"black")
'''
Dessine un arc de cercle :
- de rayon 50
- avec un angle de 360° (c'est à dire un cercle, 180 pour un demi-cercle, etc)
- de coordonnées (200,200)
- de couleur noir
'''
ma_rue.ajoute_arc(50,360,(200,200),"black")
'''
Dessine un triangle :
- reliant les points de coordonnées (200,0), (300,0) et (250,100)
- de couleur noir
'''
ma_rue.ajoute_triangle([(200,0),(300,0),(250,100)],"black")

# Affichage final
ma_rue.affiche()