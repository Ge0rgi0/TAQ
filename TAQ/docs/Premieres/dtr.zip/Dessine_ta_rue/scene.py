import dessin as d 
import random

class Scene(d.Dessin):
    def __init__(self, detail : bool = False):
        """
        Initialise une scène de rue avec un ciel bleu clair et un décor de fond
        (herbe, bitume, et éventuellement des nuages).
        """
        super().__init__("deepskyblue")
        self.detail = detail
        
        if self.detail :
            self.creer_decor()
        else :
            self.aide()
    
    def aide(self):
        """
        Crée un quadrillage d'aide
        """
        for i in range(0,1600,200):
            self.ajoute_rectangle((i,-150),1,1000,"red")
        for i in range(0,1000,200):
            self.ajoute_rectangle((-50,i),1600,1,"red")
        
    def creer_decor(self):
        """
        Crée le décor de fond : herbe, bitume et nuages générés aléatoirement.
        """
        # ajouter herbe
        self.ajoute_rectangle((-250, -300), 2000, 300, "yellowgreen")
        
        # ajouter bitume
        self.ajoute_rectangle((-250, -50), 2000, 50, "slategray")
        
        # ajouter nuages
        haut_min, haut_max = 450, 550
        if random.randint(1, 2) == 1:
            self.ajouter_nuage(0, 400, haut_min, haut_max, 20, 25)
        elif random.randint(1, 2) == 1:
            self.ajouter_nuage(500, 700, haut_min, haut_max, 10, 15)
        if random.randint(1, 2) == 1:
            self.ajouter_nuage(900, 1200, haut_min, haut_max, 15, 20)

    def ajouter_nuage(self, x1: int, x2: int, y1: int, y2: int, nb1: int, nb2: int) -> None:
        """
        ajoute un nuage composé de plusieurs arcs gris et blancs.

        Args:
            x1 (int): borne minimale de la coordonnée x.
            x2 (int): borne maximale de la coordonnée x.
            y1 (int): borne minimale de la coordonnée y.
            y2 (int): borne maximale de la coordonnée y.
            nb1 (int): nombre minimal d'arcs dans le nuage.
            nb2 (int): nombre maximal d'arcs dans le nuage.
        """
        coords = [(random.randint(x1, x2), random.randint(y1, y2)) for _ in range(random.randint(nb1, nb2))]
        for coord in coords:
            self.ajoute_arc(50, 360, coord, "grey")
        for coord in coords:
            coord = coord[0] + 10, coord[1] + 20
            self.ajoute_arc(50, 360, coord, "white")

    def creer_premier_plan(self):
        """
        Crée le premier plan du décor : arbres (à certaines coordonnées fixes, aléatoires)
        et buissons répartis aléatoirement.
        """
        for coord in [300, 800, 1330]:
            if random.randint(0, 1) == 1:
                self.ajoute_arbre(coord)
    
    def ajoute_arbre(self, coord: int):
        """
        ajoute un arbre à une position donnée avec tronc et feuillage.

        Args:
            coord (int): position x du tronc de l'arbre.
        """
        hauteur = random.randint(250, 450)
        self.ajoute_rectangle((coord, -200), 40, hauteur + 250, "brown")

        coords = [(random.randint(coord - 100, coord + 100),
                   random.randint(hauteur - 50, hauteur + 60))
                  for _ in range(random.randint(20, 25))]
        
        if random.randint(0, 1) == 1:
            coords += [(random.randint(coord - 70, coord + 50),
                        random.randint(hauteur - 220, hauteur - 180))
                       for _ in range(random.randint(10, 15))]

        for coord in coords:
            self.ajoute_arc(50, 360, coord, "OliveDrab4")
        for coord in coords:
            coord = coord[0] + 10, coord[1] + 20
            self.ajoute_arc(50, 360, coord, "OliveDrab1")

        if random.randint(1, 100) == 100:
            self.ajoute_arc(8, 360, coord, "red")
        
    def affiche(self):
        """
        Ajoute le premier plan au décor puis lance l'affichage via turtle.

        Returns:
            None
        """
        if self.detail :
            self.creer_premier_plan()
        return super().affiche()
